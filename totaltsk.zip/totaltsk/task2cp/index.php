<?php 

include('../task/conn.php');

  // $sql="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id ORDER BY country_name DESC ";
  // $run=$conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Task 2</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
		}
			.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.heading
		{
			font-size: 20px;
			font-weight: bold;
		}
		.divwrap
		{
			margin-top: 20px !important;
			width: 1000px;
			margin: auto;
			margin-bottom: 20px !important;
		}
			#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

     		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	
        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
	</style>
</head>
<body>
		<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
	</div>
	<div class="divwrap">

		<table id="list">
			<thead>
				<tr>
					<th>Country</th>
					<th>Name</th>									
				</tr>				
			</thead>
			<tbody>
				<?php 
				$query="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id where c_id=1";
			    $run=$conn->query($query);
				foreach ($run as $row) { 

					    $country=$row['country_name'];
}
					?>
				<tr>

					<td><?php echo $country;  ?></td>

					<?php

					$query="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id where c_id=1";
					 $run=$conn->query($query); ?>
					<td><?php foreach($run as $row) { echo $row['first_name'] . "<br><br>";  } ?></td>
				</tr>

					<?php 
				$query="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id where c_id=2";
			    $run=$conn->query($query);
				foreach ($run as $row) { 

					    $country=$row['country_name'];
}
					?>
				<tr>

					<td><?php echo $country;  ?></td>

					<?php

					$query="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id where c_id=2";
					 $run=$conn->query($query);
					  ?>
					<td><?php foreach($run as $row) { echo $row['first_name'] . "<br><br>";  } ?></td>
				</tr>	

			<?php 
				$query="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id where c_id=3";
			    $run=$conn->query($query);
				foreach ($run as $row) { 

					    $country=$row['country_name'];
}
					?>
				<tr>

					<td><?php echo $country;  ?></td>

					<?php

					$query="SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id where c_id=3";
					 $run=$conn->query($query);
					 foreach($run as $row) { ?>
					<td><?php echo $row['first_name'];  } ?></td>
				</tr>

		

			</tbody>
		</table>
		
	</div>


</body>
</html>