<!DOCTYPE html>
<html>
<head>
	<title>Task 3 File System</title>
	<style type="text/css">
		div
		{
			width: 100px;
			margin: auto;
		}
	</style>
</head>
<body>
<div>
	<form method="post">
	<textarea name="gettext" rows="10" cols="30"></textarea><br><br>
	<button name="btn1">New</button><br><br>
	<button name="btn2">Append</button><br><br>
    <p>Read file</p>
    <p name='read'><?php $filename='log.txt'; $file = fopen("log.txt","r");
	$read=fread($file,filesize($filename));
	fclose($file); echo $read; ?></p>
	</form>
</div>
</body>

<?php

if (isset($_POST['btn2'])) 
{
	$data=$_POST['gettext'];
	$fp = fopen('log.txt', 'a');//opens file in append mode  
	fwrite($fp,'<br>'.$data);  
	fclose($fp);  	  
	echo "File appended successfully";  
	header("refresh: 1"); 
}

if (isset($_POST['btn1'])) 
{
	$data=$_POST['gettext'];
	$fp = fopen('log.txt', 'w');//opens file in write mode  
	fwrite($fp,$data);  
	fclose($fp);  	  
	echo "File appended successfully";  
	header("refresh: 1"); 

}
	


?>
</html>